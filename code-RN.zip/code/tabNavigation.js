import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, Keyboard } from "react-native";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer, CommonActions } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import {
  ProfilePage, LinkPage,
  Options,
  SurveyTwo,
  QuestionPage,
  QuestionPagePathB,
  MyAccount,
  VoiceRecordPageOne, SurveyOne,
  WelcomePage, LoginPage, SignupPage,
  VoiceRecordPagePathB, ManageAccount, ManageSubscriptions, ChangePasswordPage, FeedbackPage, EditInformation, EditInformationTwo, LegalPage, ResponseInsight, ResponseInsightPathB
} from '../screens';
import { createStackNavigator } from '@react-navigation/stack';
import { Header } from '../components';
import { color } from '../theme';
import { appText } from '../util';
import analytics from '@react-native-firebase/analytics';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const tabIconHandler = (focused, route) => {
  let iconName;
  let iconSize = 19;
  let iconColor = color.blackColor;
  if (route.name === 'Home') {
    iconName = 'home-outline';
    iconColor = focused ? color.darkGreen : color.blackColor;
    iconSize = 22;
  } else if (route.name === 'Link 1') {
    iconName = 'comment-account-outline';
    iconColor = focused ? color.darkGreen : color.blackColor;
  } else if (route.name === 'More') {
    iconName = 'dots-vertical';
    iconColor = focused ? color.darkGreen : color.blackColor;
  }

  return (
    <MaterialCommunityIcons name={iconName} size={iconSize} color={iconColor} />
  );
};

export const ProfileStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Home"
        options={{ headerShown: false }}
        component={ProfilePage}
      />
      <Stack.Screen
        name="ProfilePage"
        options={{ headerShown: false }}
        component={ProfilePage}
      />
    </Stack.Navigator>
  )
}

export const LinkStack = () => {
  return (
    <Stack.Navigator
      mode="prop"
    >
      <Stack.Screen
        name="Link 1"
        options={{ headerShown: false }}
        component={LinkPage}
        options={{
          header: props => {
            return <Header title={appText.LINK_1} {...props} />;
          },
        }}
      />
      <Stack.Screen
        name="QuestionPage"
        options={{ headerShown: false }}
        component={QuestionPage}
        options={{
          header: props => {
            return <Header title='FORM_LABEL' subHeading="Questions"  {...props} />;
          },
        }}
      />
      <Stack.Screen
        name="QuestionPagePathB"
        options={{ headerShown: false }}
        component={QuestionPagePathB}
        options={{
          header: props => {
            return <Header title='FORM_LABEL' subHeading="Questions"  {...props} />;
          },
        }}
      />
      <Stack.Screen
        name="ResponseInsight"
        options={{ headerShown: false }}
        component={ResponseInsight}
        options={{
          header: props => {
            return <Header title="Response feedback" subHeading="quesDate" {...props} />;
          },
        }
        }
      />
      <Stack.Screen
        name="ResponseInsightPathB"
        options={{ headerShown: true }}
        component={ResponseInsightPathB}
        options={{
          header: props => {
            return <Header title="Response feedback" subHeading="quesDate" {...props} />;
          },
        }}
      />
    </Stack.Navigator>
  )

}

export const moreOptionStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="More"
        options={{ headerShown: false }}
        component={Options}
      />
      <Stack.Screen
        name="MyAccount"
        options={{ headerShown: false }}
        component={MyAccount}
        options={{
          header: props => {
            return <Header title="My account" {...props} />;
          },
        }}
      />
      <Stack.Screen
        name="ManageAccount"
        options={{ headerShown: false }}
        component={ManageAccount}
        options={{
          header: props => {
            return <Header title="Manage profile" {...props} />;
          },
        }}
      />
      <Stack.Screen
        name="ChangePassword"
        options={{ headerShown: false }}
        component={ChangePasswordPage}
        options={{
          header: props => {
            return <Header title="Change Password" noRadius={true} {...props} />;
          },
        }}
      />
      <Stack.Screen
        name="FeedbackPage"
        options={{ headerShown: false }}
        component={FeedbackPage}
        options={{
          header: props => {
            return <Header title="Feedback" {...props} />;
          },
        }}
      />
      <Stack.Screen
        name="LegalPage"
        options={{ headerShown: false }}
        component={LegalPage}
        options={{
          header: props => {
            return <Header title="Legal" {...props} />;
          },
        }}
      />
      <Stack.Screen
        name="ManageSubscriptions"
        options={{ headerShown: false }}
        component={ManageSubscriptions}
        options={{
          header: props => {
            return <Header title="Manage subscriptions" {...props} />;
          },
        }}
      />
    </Stack.Navigator >
  )
}

const CustomTabBar = ({ state, descriptors, navigation }) => {

  const [keyboardStatus, setKeyboardStatus] = useState(false)

  useEffect(() => {
    Keyboard.addListener('keyboardDidShow', keyboardDidShow);
    Keyboard.addListener('keyboardDidHide', keyboardDidHide);
  }, [])

  const keyboardDidShow = () => {
    setKeyboardStatus(true)
  }

  const keyboardDidHide = () => {
    setKeyboardStatus(false)
  }
  if (keyboardStatus) {
    return (
      <View></View>
    )
  }
  return (
    <View style={{
      backgroundColor: '#fff',
      flexDirection: 'row',
      justifyContent: "space-around",
      width: "100%", paddingTop: 7,
      paddingBottom: 7,

      shadowColor: "#000",
      shadowOffset: {
        width: 0,
        height: 12,
      },
      shadowOpacity: 0.58,
      shadowRadius: 16.00,

      elevation: 24,
    }}>
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
              ? options.title
              : route.name;

        const isFocused = state.index === index;

        const onPress = async () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            let routeIndex = 0;
            let test = await state.routes.filter((r, index) => {
              if (r.name === route.name) {
                routeIndex = index;
              }
            });
            navigation.dispatch(
              CommonActions.reset({
                index: routeIndex,
                routes: [
                  { name: route.name },
                ],
              })
            );
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: 'tabLongPress',
            target: route.key,
          });
        };

        return (
          <TouchableOpacity
            accessibilityRole="button"
            accessibilityStates={isFocused ? ['selected'] : []}
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            onPress={onPress}
            onLongPress={onLongPress}
            style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
          >
            {tabIconHandler(isFocused, route)}
            <Text style={{ color: isFocused ? color.darkGreen : color.blackColor }}>
              {label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

export const TabNavigation = ({ navigation }) => {

  return (
    <Tab.Navigator
      tabBar={props => <CustomTabBar {...props} />}
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, iconColor, size }) => (tabIconHandler(focused, iconColor, size, route, navigation)),
      })}
      tabBarOptions={{
        activeTintColor: color.darkGreen,
        inactiveTintColor: color.blackColor,
        keyboardHidesTabBar: true
      }}
    >
      <Tab.Screen
        name="Home" component={ProfileStack}
      />
      <Tab.Screen
        name="Link 1"
        options={{
          tabBarLabel: appText.LINK_1
        }}
        component={LinkStack}
      />
      <Tab.Screen name="More" component={moreOptionStack} />
    </Tab.Navigator>
  )
}


const getActiveRouteName = state => {
  const route = state.routes[state.index];
  if (route.state) {
    return getActiveRouteName(route.state);
  }
  return route.name;
};
export const AuthorizedRoutes = (props) => {
  const routeNameRef = React.useRef();
  const navigationRef = React.useRef();
  React.useEffect(() => {
    const state = navigationRef.current.getRootState();
    // Save the initial route name
    routeNameRef.current = getActiveRouteName(state);
  }, []);
  return (
    <NavigationContainer
      ref={navigationRef}
      onStateChange={state => {
        const previousRouteName = routeNameRef.current;
        const currentRouteName = getActiveRouteName(state);
        if (previousRouteName !== currentRouteName) {
          analytics().setCurrentScreen(currentRouteName, currentRouteName);
        }
        routeNameRef.current = currentRouteName;
      }}
    >
      <Stack.Navigator>
        <Stack.Screen
          name="Welcome"
          options={{ headerShown: false }}
          component={WelcomePage}
        />
        <Stack.Screen
          name="Home"
          component={TabNavigation}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Login"
          options={{ headerShown: false }}
          component={LoginPage}
        />
        <Stack.Screen
          name="Signup"
          options={{ headerShown: false }}
          component={SignupPage}
        />
        <Stack.Screen
          name="SurveyOne"
          options={{ headerShown: false }}
          component={SurveyOne}
        />

        <Stack.Screen
          name="ChangePassword"
          options={{ headerShown: false }}
          component={ChangePasswordPage}
        />

        <Stack.Screen
          name="SurveyTwo"
          component={SurveyTwo}
          options={{
            header: props => {
              return <Header title={appText.STRING_7} {...props} />;
            },
          }}
        />
        <Stack.Screen
          name="VoiceRecordPageOne"
          options={{ headerShown: false }}
          component={VoiceRecordPageOne}
          options={{
            header: props => {
              return <Header title="Record answer" noRadius={true} {...props} />;
            },
          }}
        />
        <Stack.Screen
          name="VoiceRecordPagePathB"
          options={{ headerShown: false }}
          component={VoiceRecordPagePathB}
          options={{
            header: props => {
              return <Header title={appText.STRING_19} noRadius={true} {...props} />;
            },
          }}
        />
        <Stack.Screen
          name="EditInformation"
          options={{ headerShown: false }}
          component={EditInformation}
          options={{
            header: props => {
              return <Header title="Edit personal information" {...props} />;
            },
          }}
        />
        <Stack.Screen
          name="EditInformationTwo"
          options={{ headerShown: false }}
          component={EditInformationTwo}
          options={{
            header: props => {
              return <Header title="Edit professional information" {...props} />;
            },
          }}
        />
      </Stack.Navigator>
    </NavigationContainer >
  )
}
