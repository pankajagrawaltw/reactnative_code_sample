import React, { useEffect, useState, forwardRef, useRef, useImperativeHandle } from "react";
import { View, Text, Slider, TouchableOpacity } from "react-native";
import { Audio } from 'expo-av';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { color } from "../../theme";
import { millisecondConvertor } from "../../util";
import { styles } from './audioPlayerStyles'

let sound = null;
const AudioPlayer = (props, ref) => {


  const [soundObject, setSoundObject] = useState();
  const [isLoaded, setIsLoaded] = useState(false);
  const [playStatus, setPlayStatus] = useState('LOADING');
  const [positionMillis, setPositionMillis] = useState(null)
  const [durationMillis, setDurationMillis] = useState(0);
  const [maxSliderValue, setMaxSliderValue] = useState(0);
  const [currentSliderValue, setCurrentSliderValue] = useState(0);
  const [rate, setRate] = useState(null);
  const [shouldPlay, setShouldPlay] = useState(null)
  const [isBuffering, setIsBuffering] = useState('NOT_STARTED');
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackMillis, setPlaybackMillis] = useState(0);
  const [muted, setMuted] = useState(null);
  const [volume, setVolume] = useState(null);
  const [shouldCorrectPitch, setShouldCorrectPitch] = useState(null);
  const [isPlaybackAllowed, setIsPlaybackAllowed] = useState(null);
  const [isWave, setIsWave] = useState(props.isWav ? props.isWav : false)

  useEffect(() => {
    loadSound()
  }, [])

  const loadSound = async () => {
    try {
      sound = new Audio.Sound();
      await sound.setOnPlaybackStatusUpdate(onPlaybackStatusUpdate);
      const soundInfo = await sound.loadAsync({ uri: props.uri });
      // sound.setProgressUpdateIntervalAsync(200)

      const soundStatus = await sound.getStatusAsync();

      setMaxSliderValue(soundStatus.durationMillis);
      setDurationMillis(soundStatus.durationMillis);
      setPositionMillis(soundStatus.positionMillis);
      setCurrentSliderValue(soundStatus.positionMillis);
      setShouldPlay(soundStatus.shouldPlay)
      setIsPlaying(soundStatus.isPlaying);
      setRate(soundStatus.rate);
      setMuted(soundStatus.isMuted);
      setVolume(soundStatus.volume);
      setShouldCorrectPitch(true);
      setIsPlaybackAllowed(true);
      setSoundObject(sound);
    } catch (error) {
      // An error occurred!
      console.warn(`Player.js loadSound error : ${error}`);
    }
  }

  const onPlaybackStatusUpdate = async (playbackStatus) => {

    if (playbackStatus.isLoaded) {
      if (
        playStatus !== 'PLAYING' &&
        playStatus !== 'PAUSED' &&
        playStatus !== 'STOPPED' &&
        playStatus !== 'ERROR'
      ) {
        if (playbackStatus.isLoaded && !isLoaded) {
          setIsLoaded(true);
        }
        if (isLoaded && playbackStatus.isBuffering) {
          setPlayStatus('BUFFERING');
        }
        if (
          isLoaded &&
          !playbackStatus.isBuffering &&
          playbackStatus.hasOwnProperty('durationMillis')
        ) {
          setPlayStatus('STOPPED');
        }
      }
      if (playbackStatus.isPlaying) { // This is for updating position of progress bar
        // if (!positionMillis) {
        setPositionMillis(playbackStatus.positionMillis);
        setCurrentSliderValue(playbackStatus.positionMillis);
        // }
      }

      if (playbackStatus.didJustFinish && !playbackStatus.isLooping) {  // This will execute once the audio pleayer is completed playing
        setPlayStatus('STOPPED');
        setIsPlaying(false);
        setPositionMillis(0);
        setCurrentSliderValue(0);

      }
    }
  };

  const onSliderValueChange = async (value) => {
    // setPositionMillis(value);
    soundObject.setPositionAsync(value);
  };

  const forwardAudio = async () => {
    if (currentSliderValue < durationMillis) {
      let forwardValue = currentSliderValue + 500;
      setCurrentSliderValue(forwardValue)
      soundObject.pauseAsync()
        .then(() => {
          setPlayStatus('PAUSED');
          soundObject.setPositionAsync(forwardValue);
        });
      // soundObject.playFromPositionAsync(forwardValue);
      soundObject.setPositionAsync(forwardValue);
    }
  }

  const backwordAudio = async () => {
    if (currentSliderValue) {
      let backwordValue = currentSliderValue - 500;
      setCurrentSliderValue(backwordValue)
      soundObject.pauseAsync()
        .then(() => {
          setPlayStatus('PAUSED');
          soundObject.setPositionAsync(backwordValue);
        });
      soundObject.setPositionAsync(backwordValue);

    }
  }

  const onPausePress = async () => {
    if (soundObject != null) {
      soundObject.pauseAsync()
        .then(() => {
          setPlayStatus('PAUSED');
        });
    }
  };

  useImperativeHandle(ref, () => ({
    handlePauseAudio() {
      onPausePress()
    }
  }));

  const onPlayPress = async () => {
    if (soundObject != null) {
      if (positionMillis === durationMillis) {
        soundObject.stopAsync()
          .then(() => {
            soundObject.playAsync()
              .then(() => {
                setPlayStatus('PLAYING')
              })
          });
      } else if (positionMillis === 0) {
        soundObject.replayAsync()
          .then(() => {
            setPlayStatus('PLAYING');
          })
          .catch((err) => {
            console.log("err", err);
          });

      } else {
        let position = positionMillis
        soundObject.playAsync(positionMillis)
          .then(() => {
            setPlayStatus('PLAYING');
          })
          .catch((err) => {
            console.log("err", err)
          });
      }
    }
  };

  props.progressTime && props.progressTime({ positionMillis, durationMillis });

  const renderPlayButton = () => {
    if (playStatus === 'STOPPED') {
      return (
        <TouchableOpacity onPress={() => onPlayPress()}>
          <MaterialCommunityIcons name='play-circle-outline' size={props.isResponseInsightsPlayer ? 25 : 60} color={props.isResponseInsightsPlayer ? color.grayColor : color.whiteColor} />
        </TouchableOpacity>
      )
    } else if (playStatus === 'PLAYING') {
      return (
        <TouchableOpacity onPress={() => onPausePress()}>
          <MaterialCommunityIcons name='pause-circle-outline' size={props.isResponseInsightsPlayer ? 25 : 60} color={props.isResponseInsightsPlayer ? color.grayColor : color.whiteColor} />
        </TouchableOpacity>
      )
    } else if (playStatus === 'PAUSED') {
      return (
        <TouchableOpacity onPress={() => onPlayPress()} >
          <MaterialCommunityIcons name='play-circle-outline' size={props.isResponseInsightsPlayer ? 25 : 60} color={props.isResponseInsightsPlayer ? color.grayColor : color.whiteColor} />
        </TouchableOpacity>
      )
    } else {
      return (
        <TouchableOpacity onPress={() => onPlayPress()}>
          <MaterialCommunityIcons name='play-circle-outline' size={props.isResponseInsightsPlayer ? 25 : 60} color={props.isResponseInsightsPlayer ? color.grayColor : color.whiteColor} />
        </TouchableOpacity>
      )
    }
  }


  return (
    <View style={{ flex: 1, }}>
      <View style={styles.audioPlayerMainContainer}>

        <View>
          <Text style={{ color: props.isResponseInsightsPlayer ? color.grayColor : color.whiteColor }}>{millisecondConvertor(positionMillis)}</Text>
        </View>

        <View style={styles.audioPlayerContainer}>
          <Slider
            minimimValue={0}
            maximumValue={maxSliderValue}
            value={currentSliderValue}
            onValueChange={onSliderValueChange}
            maximumTrackTintColor={props.isResponseInsightsPlayer ? color.darkGreen : color.whiteColor}
            minimumTrackTintColor={props.isResponseInsightsPlayer ? color.grayColor : color.whiteColor}
          />
        </View>
        <View>
          <Text style={{ color: props.isResponseInsightsPlayer ? color.grayColor : color.whiteColor }}>{millisecondConvertor(durationMillis)}</Text>
        </View>
      </View>


      <View style={{ marginTop: !props.isResponseInsightsPlayer ? 20 : 0, flexDirection: "row", justifyContent: props.isResponseInsightsPlayer ? "center" : "space-around" }}>
        {isWave && <TouchableOpacity onPress={() => backwordAudio()}>
          <MaterialCommunityIcons name='rewind' size={props.isResponseInsightsPlayer ? 25 : 60} color={props.isResponseInsightsPlayer ? color.grayColor : color.whiteColor} />
        </TouchableOpacity>}
        <View style={{ marginLeft: props.isResponseInsightsPlayer ? 0 : -90, marginRight: props.isResponseInsightsPlayer ? 0 : -90 }}>
          {renderPlayButton()}
        </View>
        {isWave && <TouchableOpacity onPress={() => forwardAudio()}>
          <MaterialCommunityIcons name='fast-forward' size={props.isResponseInsightsPlayer ? 25 : 60} color={props.isResponseInsightsPlayer ? color.grayColor : color.whiteColor} />
        </TouchableOpacity>}
      </View>

    </View>
  )
};

export default forwardRef(AudioPlayer);

