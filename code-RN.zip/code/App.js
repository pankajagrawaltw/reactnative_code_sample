import React from 'react';
import { StyleSheet, SafeAreaView, StatusBar, Platform } from 'react-native';
import { Navigation } from './src/navigations';
import thunk from 'redux-thunk';
import { applyMiddleware, createStore } from 'redux';
import { Provider } from 'react-redux';
import reducers from './src/reducers';

const createStoreWithMiddleware = applyMiddleware(thunk)(createStore);

export default function App() {
  return (
    <Provider store={createStoreWithMiddleware(reducers)}>
      <SafeAreaView
        forceInset={{ top: 'always' }}
        style={{
          flex: 1,
          paddingTop: Platform.OS === 'android' ? 0 : 0,

        }}
      >
        <Navigation />
      </SafeAreaView>
    </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
